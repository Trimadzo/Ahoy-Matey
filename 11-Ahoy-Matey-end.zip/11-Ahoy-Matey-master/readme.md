# Ahoy Matey
Exploring the elements of RTS network game [The Complete Unity Developer](https://www.udemy.com/unitycourse/?couponCode=GitHubSpecial) course - Udemy's most successful Unity 3D tutorial.

If you are interested in seeing how this code was written as part of our epic 40+ hour course, then use [this coupon](https://www.udemy.com/unitycourse/?couponCode=GitHubSpecial) to gain 80% of the RRP.

---
